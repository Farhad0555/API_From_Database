<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Image;
use Validator;

class ApiController extends Controller
{
    public function index()
    {
        $user=User::all();
        return response()->json([
            'message'=>count($user).'no of data found',
            'data'=>$user,
            'status'=>true,
        ]);
    }
    public function show($id)
    {
        $user = User::find($id);
       
            if($user != null)
            {
                return response()->json([
                'message'=>'Record found',
                'data'=>$user,
                'status'=>true,
            ]);
            }
            else{
                return response()->json([
                'message'=>'Record not found',
                'data'=>[],
                'status'=>false, 
                ]);
            }       
    }
    public function update(Request $request, $id)
    {
        $user = User::find($id);
        $user->name=$request->name;
        $user->email=$request->email;
        $user->save();
        return response()->json([
            'message'=>'update done',
            'data'=>$user,
            'status'=>true,
        ]);
    }
    public function edit(Request $request)
    {
        $validator =Validator::make($request->all(),[
            'name'=>'required',          
            'password'=>'required',
            'email'=>'required|email',
        ]);
        if($validator->fails()){
            return response()->json([
                'message'=>'Error detacted',
                'error'=>$validator->errors(),
                'status'=>false,
            ]);
        }
        $user = new User;
        $user->name=$request->name;
        $user->email=$request->email;
        $user->password=$request->password;
        $user->save();
        return response()->json([
            'message'=>'Record updated',
            'data'=>$user,
            'status'=>true,
        ]);
    }
    public function delete($id)
    {
        $user = User::find($id);
        $user->delete();
        return response()->json([
            'message'=>'Recod releted success',
            'status'=>true,
        ]);

    }
    public function upload(request $request)
    {  
          $validator=Validator::make($request->all(),[
        'image'=>'required|mimes:png,jpg',
    ]);
    if($validator->fails()){
        return response()->json([
            'message'=>'Image not upload',
            'status'=>false,
            'error'=>$validator->errors(),
        ]);
    }
    $imageName = time().'.'.$request->image->getClientOriginalExtension();
    $request->image->move(public_path().'/upload/',$imageName);
    $image = new Image;  
    $image->image=$imageName;
    $image->save();    
    return response()->json([
        'message'=>'Image update',
        'status'=>true,
        'data'=>$image,
        'path'=>asset('upload/'.$imageName),
    ]);
    }
}
